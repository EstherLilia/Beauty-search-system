<?php
require_once '../config/database.php';
$json = file_get_contents('php://input');
// 将 JSON 数据解码为 PHP 关联数组或对象
$data = json_decode($json, true);
// 假设前端传递的顶级分类ID是通过POST请求中的JSON数据发送的
// 这里直接设置了一个值作为示例，您可以根据需要从$data中获取
$topParentId = $data['sort_id'];
$level1Id = isset($data['level1']) ?  $data['level1'] : 0;
$level2Id = isset($data['level2']) ?  $data['level2'] : 0;
//if(empty($level2Id) && empty($topParentId)){
//    exit();
//}
$goodsName = isset($data['goods_name']) ? $data['goods_name']: null ;
// 查询所有分类
$sql = "SELECT * FROM sort"; // 假设您的分类表名为"sort"
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

// 将结果转换为关联数组，其中分类的ID作为键
$categories = [];
while ($row = $result->fetch_assoc()) {
    $categories[$row['id']] = $row;
}

// 构建1级和2级分类的树状结构

function buildTreeWithChildren($categories, $parentId = 0) {
    $tree = [];

    // 查找所有子分类
    foreach ($categories as $category) {
        if ($category['parent_id'] == $parentId) {
            // 递归查找子分类的子孙
            $category['children'] = buildTreeWithChildren($categories, $category['id']);
            // 添加子分类到树中
            $tree[] = $category;
        }
    }
    return $tree;
}

// 调用函数获取1级和2级分类
$tree = buildTreeWithChildren($categories, $topParentId);

if ($level2Id != 0) {
    $idCount = count($level2Id);
    $level2IdsStr = implode(',', $level2Id);
    $goods = getGoods($conn,$level2IdsStr,$goodsName,$idCount);
}else if($level2Id == 0 && $level1Id == 0){
    $firstIds = [];
    $secondIds = [];
    $firstSql = "select * from sort where parent_id = $topParentId";
    $firstStmts    = $conn -> prepare( $firstSql );
    $firstStmts -> execute();
    $firstResults = $firstStmts -> get_result();
    while ( $first = $firstResults -> fetch_assoc() ) { // 使用 $row 而不是 $goods
        $firstIds[] = $first['id']; // 将 $row 添加到 $goods 数组中
    }
    $firstIdsStr = implode(',', $firstIds);
    $secondSql = "select * from sort where parent_id in ($firstIdsStr)";
    $secondStmts    = $conn -> prepare( $secondSql );
    $secondStmts -> execute();
    $secondResult = $secondStmts -> get_result();
    while ( $second = $secondResult -> fetch_assoc() ) { // 使用 $row 而不是 $goods
        $secondIds[] = $second['id']; // 将 $row 添加到 $goods 数组中
    }
    $ids = array_merge($firstIds,$secondIds);
    $idsStr = implode(',', $ids);
    if(empty($goodsName)){
        $goodsSql = "select gs.*,g.* from goods_sort gs join goods g on gs.goods_id = g.id where gs.sort_id in ($idsStr)";
    }else{
        $goodsSql = "select gs.*,g.* from goods_sort gs join goods g on gs.goods_id = g.id where gs.sort_id in ($idsStr) AND g.name LIKE '%$goodsName%'";
    }

    $goodsStmts    = $conn -> prepare( $goodsSql );
    $goodsStmts -> execute();
    $goodsResult = $goodsStmts -> get_result();
    $objects = [];
    while ( $good = $goodsResult -> fetch_assoc() ) { // 使用 $row 而不是 $goods
        $objects[] = $good; // 将 $row 添加到 $goods 数组中
    }

    $goods = [];
    foreach ($objects as $object) {
        $isDuplicate = false;
        foreach ($goods as $good) {
            if (isEqual($object, $good)) {
                $isDuplicate = true;
                break;
            }
        }
        if (!$isDuplicate) {
            $goods[] = $object;
        }
    }

}

function isEqual($a, $b) {

    return $a['goods_id'] == $b['goods_id'];
}

function getGoods($conn,$id,$goodsName,$count){
    if(empty($goodsName)){
        $goodsSql = "SELECT g.id, g.name, g.pre_info, g.image
FROM goods g  
WHERE g.id IN (  
    SELECT gs.goods_id  
    FROM goods_sort gs  
    WHERE gs.sort_id IN ($id)  
    GROUP BY gs.goods_id  
    HAVING COUNT(DISTINCT gs.sort_id) = $count  
);";
    }else{
        $goodsSql = "SELECT g.id,g.name,g.pre_info, g.image  
             FROM goods g 
            WHERE g.id IN (
                SELECT gs.goods_id
                FROM goods_sort gs
                where gs.sort_id IN ($id)
                GROUP BY gs.goods_id
                HAVING COUNT(DISTINCT gs.sort_id) =$count
            )
        
             and  g.name LIKE '%$goodsName%'";
    }


    $stmts    = $conn -> prepare( $goodsSql ); // 使用 $goodsSql 而不是 $sql/ 绑定参数
    $stmts -> execute();
    $results = $stmts -> get_result();

    $objects = [];
    while ( $good = $results -> fetch_assoc() ) { // 使用 $row 而不是 $goods
        $objects[] = $good; // 将 $row 添加到 $goods 数组中
    }
    return $objects;
}
// 构建响应数组并发送JSON响应
$response = [
    'status' => '200',
    'message' => '获取成功',
    'data' => ['tree' => $tree,'goods' => $goods],
];
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
exit();