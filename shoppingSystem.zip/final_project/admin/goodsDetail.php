<?php
require_once  '../config/database.php';
$json = file_get_contents('php://input');

// 将 JSON 数据解码为 PHP 关联数组或对象
$data = json_decode($json, true);
$id = $data['goods_id'];

$sql = "select * from goods where id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $goodsData = array();

    // 遍历结果集并将数据添加到数组中
    while ($row = $result->fetch_assoc()) {
        $goodsData[] = $row;
    }

    // 构建响应数组并发送JSON响应
    $response = array(
        'status' => '200',
        'message' => '商品数据获取成功',
        'data' => $goodsData
    );
    echo json_encode($response);
    exit();
} else {
    $response = array('status' => '201', 'message' => '获取失败');
    echo json_encode($response);
    exit();
}