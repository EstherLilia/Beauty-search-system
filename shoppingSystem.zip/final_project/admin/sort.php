<?php
//$json = file_get_contents('php://input');
//
//// 将 JSON 数据解码为 PHP 关联数组或对象
//$data = json_decode($json, true);
require_once '../config/database.php';
$level = 0;
$parent_id = 0;
$sql = "select * from sort where level = ? and parent_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ii',$level,$parent_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    // 初始化一个空数组来存储商品数据
    $sortData = array();

    // 遍历结果集并将数据添加到数组中
    while ($row = $result->fetch_assoc()) {
        $sortData[] = $row;
    }

    // 构建响应数组并发送JSON响应
    $response = array(
        'status' => '200',
        'message' => '获取成功',
        'data' => $sortData
    );
    echo json_encode($response);
    exit();
} else {
    $response = array('status' => '201', 'message' => '获取失败');
    echo json_encode($response);
    exit();
}