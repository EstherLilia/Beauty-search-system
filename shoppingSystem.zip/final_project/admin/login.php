<?php
require_once '../config/database.php';

$json = file_get_contents('php://input');

// 将 JSON 数据解码为 PHP 关联数组或对象
$data = json_decode($json, true);
// 获取 GET 请求参数
$username = $data["username"];
$password = $data["password"];
if(empty($username) || empty($password)){
    $response = array('status' => '201', 'message' => 'Email or password cannot be empty!');
    echo json_encode($response);
    exit();
}

// 注意：这里仅作为示例，实际开发中应该使用预处理语句和参数化查询来避免 SQL 注入
$sql = "SELECT * FROM admin_user WHERE username = ? AND password = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // 登录成功，但不应直接重定向，而是返回成功信息给 AJAX
    $token = generateToken();
    $time = time();
    $sql = "UPDATE admin_user SET token = ? , token_time = $time WHERE username = ?  and password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $token, $username,$password);
    $stmt->execute();
    $response = array('status' => '200', 'message' => 'Login successful','data' => $token);
    // 注意：这里我们没有关闭连接，因为 PHP 会在脚本结束时自动关闭它
    echo json_encode($response);
    exit();
} else {
    // 登录失败，返回错误信息给 AJAX
    $response = array('status' => '201', 'message' => 'Login failed. The email address or password is incorrect');
    echo json_encode($response);
    exit();
}

// 生成一个安全的随机token
function generateToken($length = 32) {
    $bytes = openssl_random_pseudo_bytes($length);
    if (false === $bytes) {
        throw new Exception("Could not generate random bytes");
    }

    return bin2hex($bytes); // 将二进制转换为十六进制字符串
}