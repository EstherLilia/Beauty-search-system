<?php
require_once '../config/database.php';
$json = file_get_contents('php://input');

// 将 JSON 数据解码为 PHP 关联数组或对象
$data = json_decode($json, true);
$email = $data['email'];
$old_password = $data['old_password'];
$new_password = $data['new_password'];

// 首先，检查Email是否存在
$sql = "SELECT * FROM admin_user WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // 获取用户的记录
    $user = $result->fetch_assoc();
    // 验证旧密码
    if ($old_password == $user['password']) {
        // 旧密码正确，更新密码
//        $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
        // 更新密码的SQL语句
        $update_sql = "UPDATE admin_user SET password = ? WHERE email = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ss", $new_password, $email);
        $update_stmt->execute();
        // 检查是否更新成功
        if ($update_stmt->affected_rows > 0) {
            // 密码更新成功
            $response = array('status' => '200', 'message' => 'Password updated successfully');
        } else {
            // 密码更新失败
            $response = array('status' => '201', 'message' => 'Password update failed, please try again later');
        }
    } else {
        // 旧密码不正确
        $response = array('status' => '201', 'message' => 'The old password is incorrect');
    }

    // 输出响应并退出
    echo json_encode($response);
    exit();
} else {
    // Email不存在
    $response = array('status' => '201', 'message' => 'Email does not exist');
    echo json_encode($response);
    exit();
}