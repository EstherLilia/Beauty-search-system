<?php
require_once '../config/database.php';
$json = file_get_contents('php://input');

// 将 JSON 数据解码为 PHP 关联数组或对象
$data = json_decode($json, true);
$username = $data['username'];
$email = $data['email'];
$password = $data['password'];
if (empty($username) || empty($email) || empty($password)) {
    $response = array('status' => '201', 'message' => 'Email or password or username cannot be empty!');
    echo json_encode($response);
    exit();
}

// 检查Email是否已存在
$sql_check = "SELECT * FROM admin_user WHERE email = ?";
$stmt_check = $conn->prepare($sql_check);
//if (!$stmt_check) {
//    // 预处理失败，输出错误信息
//    die('预处理语句失败: ' . $conn->error);
//}
$stmt_check->bind_param("s", $email);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    // Email已存在
    $response = array('status' => '201', 'message' => 'Email has been registered, please use another Email.');
    echo json_encode($response);
    exit();
}

// 如果Email不存在，则继续注册过程
$token = generateToken();
$time = time();
$sql = "INSERT INTO admin_user(username,email,password,token,token_time) VALUES (?,?,?,?,?)";
$stmt = $conn->prepare($sql);

// 注意：密码应该被安全地存储，例如使用password_hash()函数
// 这里为了简化示例，我们假设密码已经是哈希过的
$stmt->bind_param("sssss", $username, $email, $password, $token, $time);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    // 注意：这里不需要$result，因为INSERT操作不返回结果集，而是使用affected_rows属性
    $response = array('status' => '200', 'message' => 'Registered successfully', 'data' => $token);
    echo json_encode($response);
    exit();
} else {
    // 注册失败，返回错误信息给AJAX
    $response = array('status' => '201', 'message' => 'Registration failed, please try again later');
    echo json_encode($response);
    exit();
}

function generateToken($length = 32)
{
    $bytes = openssl_random_pseudo_bytes($length);
    if (false === $bytes) {
        throw new Exception("Could not generate random bytes");
    }

    return bin2hex($bytes); // 将二进制转换为十六进制字符串
}