<?php
require_once 'database.php';
$token = $_GET['token'];

$sql = "select * from admin_user where token = $token";
$stmt = $conn->prepare($sql);
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    return true;
}else{
    return false;
}