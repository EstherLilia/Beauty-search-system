
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin_user
-- ----------------------------
DROP TABLE IF EXISTS `admin_user`;
CREATE TABLE `admin_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(199) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(199) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(199) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `token` varchar(199) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `token_time` varchar(199) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin_user
-- ----------------------------
INSERT INTO `admin_user` VALUES (1, '111', '111', '111', NULL, NULL);
INSERT INTO `admin_user` VALUES (2, '123456@qq.com', '测试', '1234567', 'd0d1e3258b6f64125f95b003c6df8dbf8a4756cc993c99a25d06acfe7270f87a', '1715920707');
INSERT INTO `admin_user` VALUES (3, '1234567@qq.com', '123', '123456', '2a9e45ceb4c00999061b78ff0fedc44eeb309799f95b7f5444966570262ac16d', '1715742586');
INSERT INTO `admin_user` VALUES (4, '2037814451@qq.com', 'test', '1234567', '933c9b4e896620459b1cb7b3f8d0339af451e4a516ec5c0027216f56ab149346', '1715837817');

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(199) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `thumb` varchar(199) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `recommend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `price` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES (1, '商品1', NULL, '我是口红介绍', NULL);
INSERT INTO `goods` VALUES (2, '商品2', NULL, '我是口红介绍', NULL);
INSERT INTO `goods` VALUES (3, '商品3', NULL, '我是口红介绍', NULL);
INSERT INTO `goods` VALUES (4, '商品4', NULL, '我是口红介绍', NULL);
INSERT INTO `goods` VALUES (5, '商品5', NULL, '我是口红介绍', NULL);
INSERT INTO `goods` VALUES (6, '香水1', NULL, '我是香水介绍', NULL);
INSERT INTO `goods` VALUES (7, '香水2', NULL, '我是香水介绍', NULL);
INSERT INTO `goods` VALUES (8, '香水3', NULL, '我是香水介绍', NULL);
INSERT INTO `goods` VALUES (9, '香水4', NULL, '我是香水介绍', NULL);
INSERT INTO `goods` VALUES (10, '香水5', NULL, '我是香水介绍', NULL);
INSERT INTO `goods` VALUES (11, '染发膏1', NULL, '我是染发膏介绍', NULL);
INSERT INTO `goods` VALUES (12, '染发膏2', NULL, '我是染发膏介绍', NULL);
INSERT INTO `goods` VALUES (13, '染发膏3', NULL, '我是染发膏介绍', NULL);
INSERT INTO `goods` VALUES (14, '染发膏4', NULL, '我是染发膏介绍', NULL);

-- ----------------------------
-- Table structure for goods_sort
-- ----------------------------
DROP TABLE IF EXISTS `goods_sort`;
CREATE TABLE `goods_sort`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `sort_id` int(11) NOT NULL,
  `created_at` int(11) NULL DEFAULT NULL,
  `updated_at` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 35 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Records of goods_sort
-- ----------------------------
INSERT INTO `goods_sort` VALUES (1, 1, 9, NULL, NULL);
INSERT INTO `goods_sort` VALUES (2, 1, 7, NULL, NULL);
INSERT INTO `goods_sort` VALUES (3, 1, 11, NULL, NULL);
INSERT INTO `goods_sort` VALUES (4, 2, 8, NULL, NULL);
INSERT INTO `goods_sort` VALUES (5, 2, 10, NULL, NULL);
INSERT INTO `goods_sort` VALUES (6, 2, 12, NULL, NULL);
INSERT INTO `goods_sort` VALUES (7, 3, 8, NULL, NULL);
INSERT INTO `goods_sort` VALUES (8, 3, 13, NULL, NULL);
INSERT INTO `goods_sort` VALUES (9, 3, 11, NULL, NULL);
INSERT INTO `goods_sort` VALUES (10, 4, 8, NULL, NULL);
INSERT INTO `goods_sort` VALUES (11, 4, 13, NULL, NULL);
INSERT INTO `goods_sort` VALUES (12, 4, 14, NULL, NULL);
INSERT INTO `goods_sort` VALUES (13, 5, 7, NULL, NULL);
INSERT INTO `goods_sort` VALUES (14, 5, 9, NULL, NULL);
INSERT INTO `goods_sort` VALUES (15, 5, 32, NULL, NULL);
INSERT INTO `goods_sort` VALUES (16, 6, 33, NULL, NULL);
INSERT INTO `goods_sort` VALUES (17, 6, 20, NULL, NULL);
INSERT INTO `goods_sort` VALUES (18, 6, 22, NULL, NULL);
INSERT INTO `goods_sort` VALUES (19, 7, 19, NULL, NULL);
INSERT INTO `goods_sort` VALUES (20, 7, 21, NULL, NULL);
INSERT INTO `goods_sort` VALUES (21, 7, 23, NULL, NULL);
INSERT INTO `goods_sort` VALUES (22, 8, 19, NULL, NULL);
INSERT INTO `goods_sort` VALUES (23, 8, 20, NULL, NULL);
INSERT INTO `goods_sort` VALUES (24, 8, 24, NULL, NULL);
INSERT INTO `goods_sort` VALUES (25, 9, 19, NULL, NULL);
INSERT INTO `goods_sort` VALUES (26, 9, 20, NULL, NULL);
INSERT INTO `goods_sort` VALUES (27, 9, 23, NULL, NULL);
INSERT INTO `goods_sort` VALUES (28, 10, 25, NULL, NULL);
INSERT INTO `goods_sort` VALUES (29, 10, 21, NULL, NULL);
INSERT INTO `goods_sort` VALUES (30, 10, 26, NULL, NULL);
INSERT INTO `goods_sort` VALUES (31, 11, 28, NULL, NULL);
INSERT INTO `goods_sort` VALUES (32, 12, 29, NULL, NULL);
INSERT INTO `goods_sort` VALUES (33, 13, 30, NULL, NULL);
INSERT INTO `goods_sort` VALUES (34, 14, 31, NULL, NULL);

-- ----------------------------
-- Table structure for sort
-- ----------------------------
DROP TABLE IF EXISTS `sort`;
CREATE TABLE `sort`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(199) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_at` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `updated_at` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `parent_id` int(11) NULL DEFAULT 0,
  `level` tinyint(4) NULL DEFAULT 0,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 34 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sort
-- ----------------------------
INSERT INTO `sort` VALUES (1, '香水', NULL, NULL, 0, 0, 'img/xiangshui.jpg');
INSERT INTO `sort` VALUES (2, '染发膏', NULL, NULL, 0, 0, 'img/xifashui.jpg');
INSERT INTO `sort` VALUES (3, '口红', NULL, NULL, 0, 0, 'img/kouhong.jpg');
INSERT INTO `sort` VALUES (4, '质地', NULL, NULL, 3, 1, NULL);
INSERT INTO `sort` VALUES (5, '色泽', NULL, NULL, 3, 1, NULL);
INSERT INTO `sort` VALUES (6, '包装', NULL, NULL, 3, 1, NULL);
INSERT INTO `sort` VALUES (7, '丝绒', NULL, NULL, 4, 2, NULL);
INSERT INTO `sort` VALUES (8, '滋润', NULL, NULL, 4, 2, NULL);
INSERT INTO `sort` VALUES (9, '哑光', NULL, NULL, 5, 2, NULL);
INSERT INTO `sort` VALUES (10, '柔顺', NULL, NULL, 5, 2, NULL);
INSERT INTO `sort` VALUES (11, '黑色经典', NULL, NULL, 6, 2, NULL);
INSERT INTO `sort` VALUES (12, '白色经典', NULL, NULL, 6, 2, NULL);
INSERT INTO `sort` VALUES (13, '炫光', NULL, NULL, 5, 2, NULL);
INSERT INTO `sort` VALUES (14, '黑色升级款', NULL, NULL, 6, 2, NULL);
INSERT INTO `sort` VALUES (15, '香调', NULL, NULL, 1, 1, NULL);
INSERT INTO `sort` VALUES (16, '香味', NULL, NULL, 1, 1, NULL);
INSERT INTO `sort` VALUES (17, '材料', NULL, NULL, 1, 1, NULL);
INSERT INTO `sort` VALUES (19, '花香调', NULL, NULL, 15, 2, NULL);
INSERT INTO `sort` VALUES (20, '清新', NULL, NULL, 16, 2, NULL);
INSERT INTO `sort` VALUES (21, '浓郁', NULL, NULL, 16, 2, NULL);
INSERT INTO `sort` VALUES (22, '佛手甘油', NULL, NULL, 17, 2, NULL);
INSERT INTO `sort` VALUES (23, '香柠檬', NULL, NULL, 17, 2, NULL);
INSERT INTO `sort` VALUES (24, '小苍兰', NULL, NULL, 17, 2, NULL);
INSERT INTO `sort` VALUES (25, '木质调', NULL, NULL, 15, 2, NULL);
INSERT INTO `sort` VALUES (26, '小豆寇', NULL, NULL, 17, 2, NULL);
INSERT INTO `sort` VALUES (27, '颜色', NULL, NULL, 2, 1, NULL);
INSERT INTO `sort` VALUES (28, '金色', NULL, NULL, 27, 28, NULL);
INSERT INTO `sort` VALUES (29, '蓝色', NULL, NULL, 27, 2, NULL);
INSERT INTO `sort` VALUES (30, '粉色', NULL, NULL, 27, 2, NULL);
INSERT INTO `sort` VALUES (31, '棕色', NULL, NULL, 27, 2, NULL);
INSERT INTO `sort` VALUES (32, '白色升级款', NULL, NULL, 6, 2, NULL);
INSERT INTO `sort` VALUES (33, '清新调', NULL, NULL, 15, 2, NULL);

SET FOREIGN_KEY_CHECKS = 1;
