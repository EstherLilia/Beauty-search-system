const queryString = window.location.search;
const params = new URLSearchParams(queryString.substring(1));
const id = params.get("id");
let class_g = "";
axios
  .post("../../admin/goodsDetail.php", {
    goods_id: id,
  })
  .then((res) => {
    console.log(res.data);
    class_g = res.data.data;

    showBody()
     showToasts(res.data.status, res.data.message, ()=>showBody());
  });
const vcontent_body = document.querySelector(".vcontent_body");

const showBody = () => {
  let str_g = "";
  class_g.forEach((el) => {
    console.log(el, 123123123123);
    str_g += `<div class="content_body">
            <div class="item_l">
              <img src="${el.image}" alt="sample"/> 
            </div>
            <div class="item_r">
                <div class="tit">${el.name}</div>
            <div class="jieshao">${el.recommend}</div>
            </div>
        </div>`;
  });
  vcontent_body.innerHTML = str_g;
};


