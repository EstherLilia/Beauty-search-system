const d = document.createElement("div");
d.classList.add("toasts");
document.body.append(d);
let flag=true
let addClass=''
let pClass=''

const showToasts = (c, t, f) => {
  if(flag){
    flag=false
    d.classList.add("show");
    d.innerText = t;
    d.style.background = Number(c) == 200 ? "#67C23A" : "#F56C6C";
    d.style.color = "#fff";

    addClass=setTimeout(() => {
      d.classList.remove("show");
      d.classList.add("disappear");
      pClass=setTimeout(() => {
        d.classList.remove("disappear");
        f()
        flag=true
      }, 0);

    }, 1500);

  }

};


