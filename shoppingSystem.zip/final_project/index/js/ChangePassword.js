const plain = document.querySelector(".plain");
let toasts = document.querySelector(".toasts");

plain.addEventListener("click", () => {
  window.location.href = "../../index/view/index.html";
});
const sure = document.querySelector(".sure");
const mask = document.querySelector(".mask");
const s = () => {
  mask.classList.remove("maskC");
  mask.classList.add("maskS");
};
const c = () => {
  mask.classList.remove("maskS");
  mask.classList.add("maskC");
};
let toggleFlag = "x";
sure.addEventListener("click", () => {
  toggleFlag = "x";
  s();
});
const close = document.querySelector(".close");
const cancel = document.querySelector(".cancel");

cancel.addEventListener("click", () => c());
close.addEventListener("click", () => c());
const agree = document.querySelector(".agree");
let username = document.querySelector(".username");
let email = document.querySelector(".email");
let pwd = document.querySelector(".pwd");
let pwds = document.querySelector(".pwds");
let btn_login_flag = true;

agree.addEventListener("click", () => {
  if (btn_login_flag) {
    btn_login_flag = false;
      if (!username.value || !email.value || !pwd.value || !pwds.value) {
        c();
        showToasts(
          201,
          "The user name, password, or email address cannot be empty",
          () => (btn_login_flag = true)
        );
        return;
      } else {
        const rgx =
          /^[a-zA-Z0-9_.-]{5,}@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/;
        if (!rgx.test(email.value)) {
          showToasts(
            201,
            "Email format is incorrect, please re-enter",
            () => (btn_login_flag = true)
          );
          c();
          return;
        } else if (
          !/^[a-zA-Z0-9]{6,12}$/.test(pwd.value) ||
          !/^[a-zA-Z0-9]{6,12}$/.test(pwds.value)
        ) {
          showToasts(
            201,
            "Password format is incorrect, please re-enter",
            () => (btn_login_flag = true)
          );
          c();
          return;
        } else {
          axios
            .post("../../admin/editPassword.php", {
              username: username.value,
              email: email.value,
              old_password: pwd.value,
              new_password: pwds.value,
            })
            .then((res) => {
              console.log(res.data);
              let c = res.data.status == 200 ? "#67C23A" : "#F56C6C";
              if (res.data.status == 200) {
                btn_login_flag = false;
                localStorage.clear();
                showToasts(res.data.status, "Modify successfully, please log in again！", () => {
                  window.location.href = "../../home.html";
                  btn_login_flag = true;
                });
              } else {
                showToasts(
                  res.data.status,
                  res.data.measage,
                  () => (btn_login_flag = true)
                );
              }
              c();
            });
        }
      }

  }
});

