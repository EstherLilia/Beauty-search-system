
let  class_t=[]
let  class_g=[]
let tClassId = '';
let oClassId=''





const uvhtml = document.querySelector(".uvhtml");
const card_content = document.querySelector(".card_content");

const queryString = window.location.search;
const params = new URLSearchParams(queryString.substring(1));
const id = params.get('id');
window.addEventListener('load',()=>{

  axios.post('../../admin/search.php', {
    'sort_id' :id,
  }).then(res => {
    console.log(res.data);
    let c = res.data.status == 200 ? "#67C23A" : "#F56C6C"
    if(res.data.status == 200){
      class_t=res.data.data.tree;
      class_g=res.data.data.goods;
      let s=''
      let t=''
      let u=''
      class_t.forEach(el=>{
        console.log(el,123)
        t=`<li data-classId="${el.id}" style="margin: 0 5px" >${el.name}:</li>`
        // s +=`<li data-classId="${el.id}" onclick="uvhtml_item(event)">${el.name}</li>`
        s=''
        el.children.forEach(ele=>{
          s +=`<li data-classId="${ele.id}" onclick="vhtmlo(event)">${ele.name}</li>`
        })
        // s +=`<li data-classId="${el.id}" onclick="uvhtml_item(event)">${el.name}</li>`
        u += '<ul class="uvhtml">'+t+s+'</ul>'
      })
      card_content.innerHTML=u
      showBody()
    }
  })

  const serachBtn = document.querySelector(".serachBtn");
  const searchIpt = document.querySelector(".searchIpt");

  serachBtn.addEventListener("click", () => {
    axios.post('../../admin/search.php', {
      'level1':oClassId,
      'level2':tClassId,
      'goods_name':searchIpt.value,
      'sort_id' : id,
    }).then(res => {
      class_g = res.data.data.goods;
      showBody()
    })
  });
})

const vhtmlt = document.querySelector(".vhtmlt");

const uvhtml_item=(e) => {
  oClassId = e.target.dataset.classid;
  e.target.classList.add("act");

  let s=''
  class_t.forEach(el=>{
    if (e.target.dataset.classid==el.id){
      el.children.forEach(ele=>{
        s +=`<li data-classId="${ele.id}" onclick="vhtmlo(event)">${ele.name}</li>`
      })
    }
  })
}
const vhtmlo = (e) => {

  e.target.classList.toggle("act");
  if (tClassId.includes(e.target.dataset.classid)){
    tClassId=tClassId.filter(el=>el!=e.target.dataset.classid)
  }else{
    tClassId = [...tClassId,e.target.dataset.classid];
  }
if(tClassId.length > 0){
  axios.post('../../admin/search.php', {
    'level2':tClassId,
    'sort_id' : id
  }).then(res => {
    console.log(res.data);
    class_g = res.data.data.goods;
    showBody()
  })
}else{ axios.post('../../admin/search.php', {
  'sort_id' :id,
}).then(res => {
  console.log(res.data);
  if(res.data.status == 200){
    class_g=res.data.data.goods;
    showBody();
  }
})}

};

const vcontent_body = document.querySelector(".vcontent_body");
var showBody = () => {
  let flag=true
  if (class_g.length ==0){
    flag=false
    showToasts(201,'Sorry, there are no related products',()=>{
      flag=true
    })
  }
  let str_g = "";
  class_g.forEach((el) => {
    str_g += `<div class="content_body">
            <div class="item_l">
              <img src="${el.image}" alt="sample"/> 
            </div>
            <div class="item_r">
              <div class="tit">${el.name}</div>
              <div class="jieshao">${el.pre_info}</div>
                <div class="lookdetail"><span class="one" data-id="${el.id}" onclick="lookGoodsDetail(event)">details</span></div>
            </div>
        </div>`;
  });
  vcontent_body.innerHTML = str_g;
};

const  lookGoodsDetail=(e) => {
  console.log(e.target.dataset.id)
  window.location.href = `../view/goodsDetail.html?id=${e.target.dataset.id}`;
}

