// import {axios} from "../utiles/axios";

let login = document.getElementById("login");
let register = document.getElementById("register");
let form_box = document.getElementsByClassName("form-box")[0];
let register_box = document.getElementsByClassName("register-box")[0];
let login_box = document.getElementsByClassName("login-box")[0];
// 去注册按钮点击事件
const gologin = () => {
  form_box.style.transform = "translateX(0%)";
  register_box.classList.add("hidden");
  login_box.classList.remove("hidden");
};
register.addEventListener("click", () => {
  form_box.style.transform = "translateX(83%)";
  login_box.classList.add("hidden");
  register_box.classList.remove("hidden");
});
// 去登录按钮点击事件
login.addEventListener("click", () => gologin());

let btn_login = document.getElementById("btn_login");
let username = document.querySelector(".l_username");
let password = document.querySelector(".l_password");
let toasts = document.querySelector(".toasts");
let btn_login_flag = true;
btn_login.addEventListener("click", () => {
  if (btn_login_flag) {
    btn_login_flag = false;
    if (!username.value || !password.value) {
      showToasts(201, "The user name or password cannot be empty", () => btn_login_flag = true);
    } else {
      if (/^[a-zA-Z0-9]{6,12}$/.test(password.value)) {
        axios
          .post('../final_project/admin/login.php', {
            // 注意这里只传递 URL 字符串作为第一个参数
            username: username.value,
            password: password.value,
          })
          .then((res) => {
            console.log(res);
             showToasts(res.data.status, res.data.message, () => {
              if (res.data.status == 200) {
                window.location.href = "../final_project/index/view/index.html";
              }
              btn_login_flag = true;
            });
          });
      } else {
        showToasts(201, "Incorrect password format", () => {
          btn_login_flag = true;
        });
      }
    }
  }
});
let btn_register = document.getElementById("btn_register");
let r_username = document.querySelector(".r_username");
let r_email = document.querySelector(".r_email");
let r_pwd = document.querySelector(".r_pwd");
let r_pwds = document.querySelector(".r_pwds");
btn_register.addEventListener("click", () => {
  if (btn_login_flag) {
    btn_login_flag = false;
    if (!r_username.value || !r_email.value || !r_pwd.value || !r_pwds.value) {

      showToasts(
        201,
        "The user name, password, or email address cannot be empty",
        () => (btn_login_flag = true)
      );
    } else {
      const rgx =
        /^[a-zA-Z0-9_.-]{5,}@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/;
      if (!rgx.test(r_email.value)) {
        return showToasts(
          201,
          "Email format is incorrect, please re-enter",
          () => (btn_login_flag = true)
        );
      } else if (
        !/^[a-zA-Z0-9]{6,12}$/.test(r_pwd.value) ||
        !/^[a-zA-Z0-9]{6,12}$/.test(r_pwds.value)
      ) {
         showToasts(
          201,
          "Password format is incorrect, please re-enter",
          () => (btn_login_flag = true)
        );
      } else if (r_pwd.value != r_pwds.value) {
         showToasts(
          201,
          "The two passwords are inconsistent. Please re-enter them",
          () => (btn_login_flag = true)
        );
      } else {
        axios
          .post("admin/register.php", {
            // 注意这里只传递 URL 字符串作为第一个参数
            username: r_username.value,
            email: r_email.value,
            password: r_pwd.value,
          })
          .then((res) => {
            console.log(res);
            showToasts(res.data.status, res.data.message, () => {
              res.data.status == 200 && gologin();
              btn_login_flag = true;
            })
          });
      }
    }
  }
});
