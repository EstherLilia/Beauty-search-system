
const  changePwd=()=>window.location.href='../view/ChangePassword.html'


const  loginout=()=> window.location.href = "../../home.html";



