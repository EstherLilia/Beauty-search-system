import tkinter as tk
from tkinter import messagebox, font
import mysql.connector
import hashlib
from datetime import datetime

## Register function
def register():
    username = register_entry_username.get()
    password = register_entry_password.get()
    age = register_entry_age.get() 
   
 
    ##If the age is less than 18, you cannot register
    if int(age) < 18:   messagebox.showerror("Age incompatibility","Under the age of 18, you cannot register and purchase funds")
    else:
        query = f"INSERT INTO Users (username, password, age) VALUES (%s,%s,%s)"
        ##The password is encrypted using the hash algorithm of sha256(Ensure data escurity )
        values=(username,hashlib.sha256(password.encode('utf-8')).hexdigest(),int(age))
        cursor.execute(query,values)
        make_connect.commit()

        messagebox.showinfo("Registered successfully", "Welcome！")
    register_entry_username.delete(0, tk.END)
    register_entry_password.delete(0, tk.END)
    register_entry_age.delete(0,tk.END)

##Login function
def login():
    username = login_entry_username.get()
    password = login_entry_password.get()
    
    # SQL (Select records)
    query = "SELECT * FROM Users"
    cursor.execute(query)
    users = cursor.fetchall()

    found = False
    for user in users:
        if user[1] == username:
            found = True
            if user[2] == hashlib.sha256(password.encode("utf-8")).hexdigest():
                messagebox.showinfo("Registered successfully", "Welcome！")
                ##Global variable assignment
                global current_user_id
                current_user_id = user[0]
                ##Lighten the function buttons(use normally)
                edit_button.config(state="normal")
                info_button.config(state="normal")
                account_button.config(state="normal")
                buy_fund_button.config(state="normal")
                detail_button.config(state="normal")
            else:
                messagebox.showerror("Error input", "Enter the right code")

    if found == False: 
                messagebox.showwarning("User does not exist", "The user was not found, please register first")
    ##Clear input
    login_entry_username.delete(0, tk.END)
    login_entry_password.delete(0, tk.END)

def editUserInfo():
    edit_window = tk.Toplevel(window)
    edit_window.title("Edit User Information")
    edit_window.geometry(f"300x220+{(screen_width-300)//2}+{(screen_height-220)//2}")
    window.resizable(False, False)

   # Database Querying user information
    query = "SELECT * FROM Users WHERE userId=%s"
    cursor.execute(query,(current_user_id,))
    user = cursor.fetchone()
    username = user[1]
    address = user[3]
    phonenumber = user[4]

    def updateInfo():
        username = edit_username_entry.get()
        address = edit_address_entry.get()
        phonenumber = edit_phonenumber_entry.get()

        query = "UPDATE Users SET username=%s,address=%s,phone_number=%s WHERE userId=%s"
        values = (username, address, phonenumber, current_user_id)
        cursor.execute(query,values)
        make_connect.commit()

        messagebox.showinfo("Succeeded "," User information modified successfully!")
        edit_window.destroy()

    def updatePwd():
        updatePwd_window = tk.Toplevel(edit_window)
        updatePwd_window.title("Change password")
        updatePwd_window.geometry(f"150x100+{(screen_width-150)//2}+{(screen_height-100)//2}")

        def newPwdToDB():
            if hashlib.sha256(old_pwd_entry.get().encode('utf-8')).hexdigest() != user[2]:
                messagebox.showerror("Password error "," Original password entered incorrectly")
            else:
                query = "UPDATE Users SET password=%s where userId=%s"
                cursor.execute(query,(hashlib.sha256(new_pwd_entry.get().encode('utf-8')).hexdigest(),current_user_id))
                make_connect.commit()
                messagebox.showinfo("Succeeded "," User information modified successfully!")
                updatePwd_window.destroy()
        
        def newPwdCancel():
            updatePwd_window.destroy()

        old_pwd_label = tk.Label(updatePwd_window,text="Original:")
        old_pwd_label.place(x=10,y=10,width=60,height=25)
        old_pwd_entry = tk.Entry(updatePwd_window)
        old_pwd_entry.place(x=70,y=10,width=70,height=25)

        new_pwd_label = tk.Label(updatePwd_window,text="Updated:")
        new_pwd_label.place(x=10,y=40,width=60,height=25)
        new_pwd_entry = tk.Entry(updatePwd_window)
        new_pwd_entry.place(x=70,y=40,width=70,height=25)

        confirm_pwd_button = tk.Button(updatePwd_window, text="Verfy", command=newPwdToDB,bg='blue')
        confirm_pwd_button.place(x=20,y=70,width=40,height=20)

        cancel_pwd_button = tk.Button(updatePwd_window, text="Cancle", command=newPwdCancel,bg='red')
        cancel_pwd_button.place(x=90,y=70,width=40,height=20)

        updatePwd_window.mainloop()

    
    def cancel():
        edit_window.destroy()

    edit_username_label = tk.Label(edit_window, text="UserName:")
    edit_username_label.place(x=20,y=20,width=60,height=30)
    edit_username_entry = tk.Entry(edit_window)
    edit_username_entry.place(x=100,y=20,width=180,height=30)
    edit_username_entry.insert(tk.END,username)

    edit_address_label = tk.Label(edit_window, text="Address:")
    edit_address_label.place(x=20,y=70,width=60,height=30)
    edit_address_entry = tk.Entry(edit_window)
    edit_address_entry.place(x=100,y=70,width=180,height=30)
    if address is not None:   edit_address_entry.insert(tk.END,address)

    edit_phonenumber_label = tk.Label(edit_window, text="PhoneNumber:")
    edit_phonenumber_label.place(x=20,y=120,width=60,height=30)
    edit_phonenumber_entry = tk.Entry(edit_window)
    edit_phonenumber_entry.place(x=100,y=120,width=180,height=30)
    if phonenumber is not None:   edit_phonenumber_entry.insert(tk.END,phonenumber)

    confirm_button = tk.Button(edit_window, text="Verify", command=updateInfo,bg='blue')
    confirm_button.place(x=20,y=170,width=80,height=30)

    changePwd_button = tk.Button(edit_window, text="Change password",command=updatePwd,bg='pink')
    changePwd_button.place(x=110,y=170,width=80,height=30)

    cancel_button = tk.Button(edit_window, text="Cancel",command=cancel,bg='red')
    cancel_button.place(x=200,y=170,width=80,height=30)

    edit_window.mainloop()


##Fund information query
def fundInfo():
    fund_info_window = tk.Toplevel(window)
    fund_info_window.title("Fund information")
    fund_info_window.geometry(f"600x500+{(screen_width-600)//2}+{(screen_height-500)//2}")
    fund_info_window.resizable(False,False)
    ##SQl query
    query = "SELECT * FROM funds"
    cursor.execute(query)
    funds = cursor.fetchall()

     ## Set header
    header_labels = ["ID", "FundName", "Price"]
    for i, header in enumerate(header_labels):
        fund_info_head_font = font.Font(size=24,weight="bold")
        fund_info_label = tk.Label(fund_info_window, text=header, font=fund_info_head_font)
        fund_info_label.place(x=(i * 200 + 50), y=20)

    
    ## Iteration and present the data line by line
    for i, row in enumerate(funds):
        for j, value in enumerate(row):
            fund_info_label = tk.Label(fund_info_window, text=value)
            fund_info_label.place(x=(j * 200 + 65), y=((i + 3) * 30))
    fund_info_window.mainloop()

# Present personal informatin
def personalInfo():
    personal_info_window = tk.Toplevel(window)
    personal_info_window.title("Individual account")
    personal_info_window.geometry(f"600x500+{(screen_width-600)//2}+{(screen_height-500)//2}")
    personal_info_window.resizable(False,False)

    query = "SELECT * FROM accounts"
    cursor.execute(query)
    accounts = cursor.fetchall()

    header_labels = ["FundName","seller","total amount"]
    for i, header in enumerate(header_labels):
        personal_info_head_font = font.Font(size=15,weight="bold")
        personal_info_label = tk.Label(personal_info_window, text=header, font=personal_info_head_font)
        personal_info_label.place(x=(i * 200+50), y=20)
    
    i = 0
    for account in accounts:
        if account[1]==current_user_id:
            cursor.execute("SELECT name, price FROM funds WHERE id=%s",(account[2],))
            fund_fetch_res = cursor.fetchone()
            name = fund_fetch_res[0]
            total_price = fund_fetch_res[1]*account[3]

            cursor.execute("SELECT name from sellers WHERE id=%s",(account[4],))
            seller = cursor.fetchone()

            personal_info_label = tk.Label(personal_info_window, text=name)
            personal_info_label.place(x = 80, y = (i + 2) * 30)
            personal_info_label = tk.Label(personal_info_window, text=seller)
            personal_info_label.place(x = 270, y = (i + 2) * 30)
            personal_info_label = tk.Label(personal_info_window, text=total_price)
            personal_info_label.place(x = 450, y = (i + 2) * 30)
            i += 1

    personal_info_window.mainloop()

# Transaction function
def deal():
    deal_window = tk.Toplevel(window)
    deal_window.title("fund transaction")
    deal_window.geometry(f"200x80+{(screen_width-200)//2}+{(screen_height-80)//2}")
    deal_window.resizable(False, False)

    # Buying function
    def buy_fund():
        buy_fund_window = tk.Toplevel(deal_window)
        buy_fund_window.title("Buying function")
        buy_fund_window.geometry(f"300x200+{(screen_width-300)//2}+{(screen_height-200)//2}")
        buy_fund_window.resizable(False,False)

        def cancel():
            buy_fund_window.destroy()

         #Updated database function
        def buy_in():
            fund_id = buy_fund_id_entry.get()
            fund_amount = buy_fund_amount_entry.get()
            fund_seller = buy_fund_seller_entry.get()

            buy_fund_id_entry.delete(0,tk.END)
            buy_fund_amount_entry.delete(0,tk.END)
            buy_fund_seller_entry.delete(0,tk.END)

            query = "SELECT * FROM funds WHERE id=%s"
            cursor.execute(query, (fund_id,))
            fund = cursor.fetchall()

            current_datetime = datetime.now()

            current_date = current_datetime.strftime('%Y-%m-%d')
            current_time = current_datetime.strftime('%H:%M:%S')

            if len(fund) == 0:
                messagebox.showerror("Error","The fund could not be found")
            else:
                #Generate a bill
                query = "INSERT INTO bills (UId, FId, SId, Date, Time, amount) VALUES (%s, %s, %s, %s, %s, %s);"
                cursor.execute(query,(current_user_id,fund_id,fund_seller,current_date,current_time,fund_amount))
                make_connect.commit()
               # Find out if the user has already purchased the fund (overlay purchase or new purchase)
                query = "SELECT * FROM accounts WHERE Fid=%s AND Uid=%s"
                cursor.execute(query,(fund_id,current_user_id))
                account = cursor.fetchone()

                if account is not None:
                    current_amount = account[3] + int(fund_amount)
                    query = "UPDATE accounts SET Amount = %s WHERE Fid = %s"
                    cursor.execute(query,(current_amount,fund_id))
                else:
                    query = "INSERT INTO accounts (Uid,Fid,Amount,Sid) VALUES (%s,%s,%s,%s);"
                    cursor.execute(query,(current_user_id,fund_id,fund_amount,fund_seller))
                
                messagebox.showinfo("Success "," Fund purchase success!")
                make_connect.commit()


        buy_fund_id_label = tk.Label(buy_fund_window, text="Fund number:")
        buy_fund_id_label.place(x=50,y=20,width=80,height=20)
        buy_fund_id_entry = tk.Entry(buy_fund_window)
        buy_fund_id_entry.place(x=120,y=20,width=130,height=20)

        buy_fund_amount_label = tk.Label(buy_fund_window, text="Purchase amount:")
        buy_fund_amount_label.place(x=50,y=60,width=80,height=20)
        buy_fund_amount_entry = tk.Entry(buy_fund_window)
        buy_fund_amount_entry.place(x=120,y=60,width=130,height=20)

        buy_fund_seller_label = tk.Label(buy_fund_window, text="Seller number:")
        buy_fund_seller_label.place(x=40,y=100,width=80,height=20)
        buy_fund_seller_entry = tk.Entry(buy_fund_window)
        buy_fund_seller_entry.place(x=120,y=100,width=130,height=20)

        buy_fund_confirm_button = tk.Button(buy_fund_window, text="Verify", command=buy_in,bg='blue')
        buy_fund_confirm_button.place(x=50,y=140, width=80, height=30)
        buy_fund_cancel_button = tk.Button(buy_fund_window, text="Cancel", command=cancel,bg='red')
        buy_fund_cancel_button.place(x=170,y=140, width=80, height=30)

        buy_fund_window.mainloop()

          # Sell fund function
    def sell_fund():
        sell_fund_window = tk.Toplevel(deal_window)
        sell_fund_window.title("Sell fund ")
        sell_fund_window.geometry(f"300x150+{(screen_width-300)//2}+{(screen_height-150)//2}")

        def cancel():
            sell_fund_window.destroy()

        def sell_out():
            fund_id = sell_fund_id_entry.get()
            fund_amount = sell_fund_amount_entry.get()

            sell_fund_id_entry.delete(0, tk.END)
            sell_fund_amount_entry.delete(0, tk.END)

            query = "SELECT * FROM funds WHERE id=%s"
            cursor.execute(query, (fund_id,))
            fund = cursor.fetchall()

            current_datetime = datetime.now()

            current_date = current_datetime.strftime('%Y-%m-%d')
            current_time = current_datetime.strftime('%H:%M:%S')
            
            if len(fund) == 0:
                messagebox.showerror("Error "," Fund not found")
            else:
                query = "INSERT INTO bills (UId,FId,Date,Time,amount) VALUES (%s,%s,%s,%s,%s);"
                cursor.execute(query,(current_user_id,fund_id,current_date,current_time,-1*int(fund_amount)))
                make_connect.commit()

                query = "SELECT * FROM accounts WHERE Fid=%s AND Uid=%s"
                cursor.execute(query,(fund_id,current_user_id))
                account = cursor.fetchone()

                if len(account)>0:
                    current_amount = account[3] - int(fund_amount)
                    if current_amount > 0:
                        query = "UPDATE accounts SET Amount = %s WHERE Fid = %s AND Uid=%s"
                        cursor.execute(query,(current_amount,fund_id, current_user_id))
                        messagebox.showinfo("Success "," Success in selling funds!")
                    elif current_amount == 0:
                        query = "DELETE FROM accounts WHERE Fid = %s AND Uid=%s"
                        cursor.execute(query,(fund_id, current_user_id))
                        messagebox.showinfo("Success "," All funds sold!")
                    else:
                        messagebox.showerror("Error "," Sell value greater than account value")
                    make_connect.commit()
                else:
                    messagebox.showerror("Error "," You have not purchased the fund")
        sell_fund_id_label = tk.Label(sell_fund_window, text="Fund number:")
        sell_fund_id_label.place(x=50,y=20,width=80,height=20)
        sell_fund_id_entry = tk.Entry(sell_fund_window)
        sell_fund_id_entry.place(x=120,y=20,width=130,height=20)

        sell_fund_amount_label = tk.Label(sell_fund_window, text="Amount sold:")
        sell_fund_amount_label.place(x=50,y=60,width=80,height=20)
        sell_fund_amount_entry = tk.Entry(sell_fund_window)
        sell_fund_amount_entry.place(x=120,y=60,width=130,height=20)

        buy_fund_confirm_button = tk.Button(sell_fund_window, text="Verify", command=sell_out,bg='blue')
        buy_fund_confirm_button.place(x=50,y=100, width=80, height=30)
        buy_fund_cancel_button = tk.Button(sell_fund_window, text="Cancel", command=cancel,bg='red')
        buy_fund_cancel_button.place(x=170,y=100, width=80, height=30)

        sell_fund_window.mainloop()

    buy_button = tk.Button(deal_window, text="Purchase fund", command=buy_fund,bg='red')
    buy_button.place(x=10,y=25,width=90,height=30)
    sell_button = tk.Button(deal_window, text="Selling fund", command=sell_fund,bg='green')
    sell_button.place(x=110,y=25,width=90,height=30)

    deal_window.mainloop()

# Transaction detail function
def detailInfo():
    detail_info_window = tk.Toplevel(window)
    detail_info_window.title("Transaction detail")
    detail_info_window.geometry(f"800x500+{(screen_width-800)//2}+{(screen_height-500)//2}")
    detail_info_window.resizable(False,False)

    query = "SELECT * FROM bills"
    cursor.execute(query)
    bills = cursor.fetchall()

    header_labels = ["FundName","Trader","Trading Date","TradingHours","Total"]
    for i, header in enumerate(header_labels):
        detail_info_head_font = font.Font(size=15,weight="bold")
        detail_info_label = tk.Label(detail_info_window, text=header, font=detail_info_head_font,justify="center")
        detail_info_label.place(x=(i * 160+80), y=20)

    i = 0
    for bill in bills:
        if bill[1]==current_user_id:
            cursor.execute("SELECT name, price FROM funds WHERE id=%s",(bill[2],))
            fund_fetch_res = cursor.fetchone()
            name = fund_fetch_res[0]
            total_price = fund_fetch_res[1]*bill[6]

            cursor.execute("SELECT name from sellers WHERE id=%s",(bill[3],))
            seller = cursor.fetchone()

            detail_info_label = tk.Label(detail_info_window, text=name)
            detail_info_label.place(x = 80, y = (i + 2) * 30)
            detail_info_label = tk.Label(detail_info_window, text=seller)
            detail_info_label.place(x = 220, y = (i + 2) * 30)
            detail_info_label = tk.Label(detail_info_window, text=bill[4])
            detail_info_label.place(x = 380, y = (i + 2) * 30)
            detail_info_label = tk.Label(detail_info_window, text=bill[5])
            detail_info_label.place(x = 550, y = (i + 2) * 30)
            detail_info_label = tk.Label(detail_info_window, text=total_price)
            detail_info_label.place(x = 690, y = (i + 2) * 30)
            i += 1

    detail_info_window.mainloop()

if __name__ == "__main__":
    # Create log in page 
    window = tk.Tk()
    window.title("Fund Management System")
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    window.geometry(f"600x500+{(screen_width-600)//2}+{(screen_height-500)//2}")
    window.resizable(False,False)

    # Connect with DB
    make_connect=mysql.connector.connect(
        host="localhost",
        user="root",
        password="555125",
        database="final"
    )

    cursor = make_connect.cursor()

    # Register
    register_frame = tk.Frame(window,borderwidth=1,relief="solid")
    register_frame.place(x=0,y=0,width=300,height=270)
    register_font=font.Font(size=24,weight="bold")
    register_label = tk.Label(register_frame,text="Register",font=register_font)
    register_label.place(x=90,y=20,width=150,height=30)
    register_label_username = tk.Label(register_frame, text="Username:")
    register_label_username.place(x=40,y=70,width=60,height=30)
    register_entry_username = tk.Entry(register_frame)
    register_entry_username.place(x=110,y=70,width=120,height=30)

    register_label_password = tk.Label(register_frame, text="Password:")
    register_label_password.place(x=40,y=120,width=60,height=30)
    register_entry_password = tk.Entry(register_frame, show="*")
    register_entry_password.place(x=110,y=120,width=120,height=30)

    register_label_age = tk.Label(register_frame, text="Year:")
    register_label_age.place(x=40,y=170,width=60,height=30)
    register_entry_age = tk.Entry(register_frame)
    register_entry_age.place(x=110,y=170,width=120,height=30)

    button_register = tk.Button(register_frame, text="Register", command=register)
    button_register.place(x=100,y=220,width=100,height=30)

    


    # Log in
    login_frame = tk.Frame(window,borderwidth=1,relief="solid")
    login_frame.place(x=0,y=270,width=300,height=230)
    login_font=font.Font(size=24,weight="bold")
    login_label = tk.Label(login_frame,text="Log in",font=login_font)
    login_label.place(x=90,y=20,width=150,height=30)
    login_label_username = tk.Label(login_frame, text="Username:")
    login_label_username.place(x=40,y=70,width=60,height=30)
    login_entry_username = tk.Entry(login_frame)
    login_entry_username.place(x=110,y=70,width=120,height=30)

    login_label_password = tk.Label(login_frame, text="Password:")
    login_label_password.place(x=40,y=120,width=60,height=30)
    login_entry_password = tk.Entry(login_frame, show="*")
    login_entry_password.place(x=110,y=120,width=120,height=30)

    button_login = tk.Button(login_frame, text="Log in", command=login)
    button_login.place(x=100,y=170,width=100,height=30)

    # Three function buttons on the right
    edit_button = tk.Button(window, text="Modify personal information",state="disabled",command=editUserInfo,background='pink',fg='black')
    edit_button.place(x=340,y=60,width=220,height=50)

    info_button = tk.Button(window, text="Fund information",state="disabled", command=fundInfo,background='pink',fg='black')
    info_button.place(x=340,y=140,width=220,height=50)

    account_button = tk.Button(window, text="Personal account",state="disabled", command=personalInfo,background='pink',fg='black')
    account_button.place(x=340,y=220,width=220,height=50)

    buy_fund_button = tk.Button(window, text="Trading fund",state="disabled", command=deal,background='pink',fg='black')
    buy_fund_button.place(x=340, y=300, width=220, height=50)

    detail_button = tk.Button(window, text="Trading detail",state="disabled", command=detailInfo,background='pink',fg='black')
    detail_button.place(x=340,y=380,width=220,height=50)

   
    current_user_id=-1

    
    window.mainloop()

    cursor.close()
    make_connect.close()










    

            
