
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for accounts
-- ----------------------------

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `Uid` int NOT NULL COMMENT 'Forign key from Users table',
  `Fid` int NOT NULL COMMENT 'Forign key from Funds table',
  `Amount` int NOT NULL,
  `Sid` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of accounts
-- ----------------------------
INSERT INTO `accounts` VALUES (1, 2, 3, 8000, 1);
INSERT INTO `accounts` VALUES (2, 2, 1, 6000, 3);
INSERT INTO `accounts` VALUES (4, 5, 2, 500, 1);
INSERT INTO `accounts` VALUES (5, 5, 5, 10000, 3);
INSERT INTO `accounts` VALUES (6, 7, 1, 5000, 2);

-- ----------------------------
-- Table structure for bills
-- ----------------------------
DROP TABLE IF EXISTS `bills`;
CREATE TABLE `bills`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `UId` int NULL DEFAULT NULL,
  `FId` int NULL DEFAULT NULL,
  `SId` int NULL DEFAULT NULL,
  `Date` date NULL DEFAULT NULL,
  `Time` time NULL DEFAULT NULL,
  `amount` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `UId`(`UId` ASC) USING BTREE,
  INDEX `FId`(`FId` ASC) USING BTREE,
  INDEX `SId`(`SId` ASC) USING BTREE,
  CONSTRAINT `bills_ibfk_1` FOREIGN KEY (`UId`) REFERENCES `users` (`userID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `bills_ibfk_2` FOREIGN KEY (`FId`) REFERENCES `funds` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `bills_ibfk_3` FOREIGN KEY (`SId`) REFERENCES `sellers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bills
-- ----------------------------
INSERT INTO `bills` VALUES (1, 2, 3, 1, '2022-02-20', '12:15:20', 3000);
INSERT INTO `bills` VALUES (2, 2, 1, 3, '2023-06-21', '15:55:41', 5800);
INSERT INTO `bills` VALUES (3, 2, 3, 2, '2023-12-03', '19:51:41', 5000);
INSERT INTO `bills` VALUES (12, 5, 1, 2, '2023-12-03', '20:24:41', 1000);
INSERT INTO `bills` VALUES (13, 5, 1, 3, '2023-12-03', '20:25:02', 4000);
INSERT INTO `bills` VALUES (14, 5, 2, 1, '2023-12-03', '20:25:54', 500);
INSERT INTO `bills` VALUES (15, 5, 1, NULL, '2023-12-03', '20:29:47', -5000);
INSERT INTO `bills` VALUES (16, 5, 5, 3, '2023-12-03', '20:30:07', 10000);
INSERT INTO `bills` VALUES (17, 7, 1, 2, '2023-12-03', '22:00:30', 1000);
INSERT INTO `bills` VALUES (18, 7, 1, 2, '2023-12-03', '22:01:03', 5000);
INSERT INTO `bills` VALUES (19, 7, 3, 1, '2023-12-03', '22:01:27', 30000);
INSERT INTO `bills` VALUES (20, 7, 1, NULL, '2023-12-03', '22:01:55', -10000);
INSERT INTO `bills` VALUES (21, 7, 3, NULL, '2023-12-03', '22:02:15', -30000);
INSERT INTO `bills` VALUES (22, 7, 1, NULL, '2023-12-03', '22:02:24', -1000);

-- ----------------------------
-- Table structure for funds
-- ----------------------------
DROP TABLE IF EXISTS `funds`;
CREATE TABLE `funds`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` float NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id`(`id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of funds
-- ----------------------------
INSERT INTO `funds` VALUES (1, 'fund1', 2.33);
INSERT INTO `funds` VALUES (2, 'fund2', 0.87);
INSERT INTO `funds` VALUES (3, 'fund3', 4.32);
INSERT INTO `funds` VALUES (4, 'fund4', 3.11);
INSERT INTO `funds` VALUES (5, 'fund5', 0.83);
INSERT INTO `funds` VALUES (6, 'fund6', 1.43);
INSERT INTO `funds` VALUES (7, 'fund7', 1.02);
INSERT INTO `funds` VALUES (8, 'fund8', 0.22);

-- ----------------------------
-- Table structure for sellers
-- ----------------------------
DROP TABLE IF EXISTS `sellers`;
CREATE TABLE `sellers`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sellers
-- ----------------------------
INSERT INTO `sellers` VALUES (1, 'Claire');
INSERT INTO `sellers` VALUES (2, 'Yuki');
INSERT INTO `sellers` VALUES (3, 'Esther');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `userID` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `age` int NULL DEFAULT NULL,
  PRIMARY KEY (`userID`) USING BTREE,
  UNIQUE INDEX `userID`(`userID` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'Allen', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', '123 Main St', '555-1234', 23);
INSERT INTO `users` VALUES (2, 'Jerry', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', '323 Main St', '233-0247', 45);
INSERT INTO `users` VALUES (3, 'Danniel', '481f6cc0511143ccdd7e2d1b1b94faf0a700a8b49cd13922a70b5ae28acaa8c5', '943 Spring St', '899-3202', 36);
INSERT INTO `users` VALUES (4, 'Luke', '481f6cc0511143ccdd7e2d1b1b94faf0a700a8b49cd13922a70b5ae28acaa8c5', '466 Winter St', '607-2383', 27);
INSERT INTO `users` VALUES (5, 'Eric', '481f6cc0511143ccdd7e2d1b1b94faf0a700a8b49cd13922a70b5ae28acaa8c5', '567 Summer St', '339-0680', 37);
INSERT INTO `users` VALUES (6, 'Shu', '481f6cc0511143ccdd7e2d1b1b94faf0a700a8b49cd13922a70b5ae28acaa8c5', '890 Spring St', '332-7880', 29);
INSERT INTO `users` VALUES (7, 'Gin', '481f6cc0511143ccdd7e2d1b1b94faf0a700a8b49cd13922a70b5ae28acaa8c5', '566 Main St', '122-3043', 35);

SET FOREIGN_KEY_CHECKS = 1;

